
def ejercicio1(n1, n2):
    while n1 < n2:
        print(n1)
        n1 += 1
    print(n1)

def ejercicio2(n, np):
    print("El resultado de la potencia es " + str(n**np))

def ejercicio3(texto):
    print ((texto)[::-1])

def ejercicio1 (n1, n2):
    print(n1+n2)
